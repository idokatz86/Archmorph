"""
Guided Questionnaire System for Archmorph
==========================================

Generates context-aware questions based on detected AWS services to customize
the Azure architecture translation. Answers influence Azure SKU selection,
redundancy configuration, compliance posture, and IaC parameters.

Usage:
    from guided_questions import generate_questions, apply_answers

    questions = generate_questions(["EC2", "S3", "Lambda", "DynamoDB", "IoT Core"])
    # → present to user, collect answers dict  {question_id: answer_value}
    adjusted = apply_answers(original_analysis, user_answers)
"""

from __future__ import annotations

import copy
from typing import Any

# ─────────────────────────────────────────────────────────────
# Type aliases
# ─────────────────────────────────────────────────────────────
Question = dict[str, Any]
QuestionBank = dict[str, list[Question]]
AnalysisResult = dict[str, Any]
Answers = dict[str, Any]


# ═════════════════════════════════════════════════════════════
# QUESTION BANK
# ═════════════════════════════════════════════════════════════
# Each question:
#   id        – unique identifier (category prefix + ordinal)
#   question  – display text
#   type      – "single_choice" | "multiple_choice" | "scale" | "text"
#   options   – list of allowed values (for choice / scale types)
#   condition – list of AWS service names that trigger inclusion;
#               empty list means *always* included
#   impact    – human-readable note on what Azure decisions this affects
#   default   – sensible default answer


import json
import os

_data_file_QUESTION_BANK = os.path.join(os.path.dirname(__file__), 'data', 'guided_questions_bank.json')
try:
    with open(_data_file_QUESTION_BANK, 'r') as _f:
        QUESTION_BANK = json.load(_f)
except FileNotFoundError:
    QUESTION_BANK = [] if False else {}



# ═════════════════════════════════════════════════════════════
# HELPERS
# ═════════════════════════════════════════════════════════════

# Service name normalisation map — handles common variations that
# appear in diagram analysis output (e.g. "Amazon S3" → "S3").
_NORMALISE: dict[str, str] = {
    "Amazon S3": "S3",
    "Simple Storage Service": "S3",
    "Amazon EC2": "EC2",
    "Elastic Compute Cloud": "EC2",
    "AWS Lambda": "Lambda",
    "Amazon DynamoDB": "DynamoDB",
    "Amazon Aurora": "Aurora",
    "Amazon RDS": "RDS",
    "Amazon Kinesis": "Kinesis",
    "Amazon Kinesis Data Firehose": "Kinesis",
    "Amazon EMR": "EMR",
    "Elastic MapReduce": "EMR",
    "Amazon Redshift": "Redshift",
    "Amazon Neptune": "Neptune",
    "Amazon DocumentDB": "DocumentDB",
    "Amazon ElastiCache": "ElastiCache",
    "Amazon EKS": "EKS",
    "Amazon ECS": "ECS",
    "AWS Fargate": "Fargate",
    "AWS IoT Core": "IoT Core",
    "AWS IoT Greengrass": "IoT Greengrass",
    "AWS IoT SiteWise": "IoT SiteWise",
    "AWS IoT TwinMaker": "IoT TwinMaker",
    "AWS IoT FleetWise": "IoT FleetWise",
    "AWS IoT Events": "IoT Events",
    "AWS IoT Analytics": "IoT Analytics",
    "Amazon API Gateway": "API Gateway",
    "Amazon CloudFront": "CloudFront",
    "AWS Direct Connect": "Direct Connect",
    "AWS Outposts": "Outposts",
    "Amazon SageMaker": "SageMaker",
    "Amazon SageMaker Ground Truth": "SageMaker",
    "Amazon Bedrock": "Bedrock",
    "Amazon Rekognition": "Rekognition",
    "AWS Glue": "Glue",
    "AWS Glue Data Catalog": "Glue",
    "Amazon MWAA": "MWAA",
    "Amazon Athena": "Athena",
    "Amazon QuickSight": "QuickSight",
    "AWS Step Functions": "Step Functions",
    "Amazon SQS": "SQS",
    "Amazon SNS": "SNS",
    "Amazon EventBridge": "EventBridge",
    "Amazon MSK": "MSK",
    "Amazon Elasticsearch Service": "OpenSearch",
    "Amazon OpenSearch Service": "OpenSearch",
    "AWS AppSync": "AppSync",
    "Amazon Cognito": "Cognito",
    "AWS CloudFormation": "CloudFormation",
    "Amazon CloudWatch": "CloudWatch",
    "Amazon MemoryDB": "MemoryDB",
    "AWS CodePipeline": "CodePipeline",
    "AWS CodeBuild": "CodeBuild",
    "AWS CodeDeploy": "CodeDeploy",
    "Amazon ECR": "ECR",
    "AWS App Runner": "App Runner",
    "AWS KMS": "KMS",
    "AWS Secrets Manager": "Secrets Manager",
    "AWS CloudHSM": "CloudHSM",
    "AWS WAF": "WAF",
    "AWS VPN": "VPN",
    "Amazon VPC": "VPC",
    "Amazon Route 53": "Route 53",
    "AWS Elastic Beanstalk": "Elastic Beanstalk",
    "Amazon Lightsail": "Lightsail",
    "AWS Batch": "Batch",
    "Amazon Timestream": "Timestream",
    "Amazon Keyspaces": "Keyspaces",
    "Amazon Personalize": "Personalize",
    "Amazon Forecast": "Forecast",
    # ── Hybrid / Multi-cloud ──
    "Amazon EKS Anywhere": "EKS Anywhere",
    "AWS Systems Manager": "SSM",
    "AWS SSM": "SSM",
    "Amazon RDS on Outposts": "RDS on Outposts",
    # ── Generative AI ──
    "Amazon Bedrock Agents": "Bedrock Agents",
    "Amazon Bedrock Knowledge Bases": "Bedrock Knowledge Bases",
    "Amazon Q Business": "Q Business",
    "Amazon Q Developer": "Q Developer",
    "Amazon SageMaker Canvas": "SageMaker Canvas",
    "Amazon Bedrock Guardrails": "Bedrock Guardrails",
    "Amazon PartyRock": "PartyRock",
    "Amazon CodeGuru": "CodeGuru",
    # ── Edge Computing ──
    "AWS Wavelength": "Wavelength",
    "AWS Local Zones": "Local Zones",
    "CloudFront Functions": "CloudFront Functions",
    "Lambda@Edge": "Lambda@Edge",
    "AWS Elastic Disaster Recovery": "Elastic Disaster Recovery",
    # ── Observability ──
    "Amazon Managed Grafana": "Managed Grafana",
    "Amazon Managed Service for Prometheus": "Managed Prometheus",
    "AWS Distro for OpenTelemetry": "Distro for OpenTelemetry",
    "Amazon CloudWatch Container Insights": "CloudWatch Container Insights",
    # ── Data Governance ──
    "Amazon DataZone": "DataZone",
    "AWS Clean Rooms": "Clean Rooms",
    "Amazon AppFlow": "AppFlow",
    "AWS Audit Manager": "Audit Manager",
    "AWS Glue DataBrew": "Glue DataBrew",
    # ── Zero Trust / SASE ──
    "AWS Verified Access": "Verified Access",
    "Amazon Security Lake": "Security Lake",
    "Amazon Detective": "Detective",
    "AWS Firewall Manager": "Firewall Manager",
    "AWS Network Firewall": "Network Firewall",
    "Amazon VPC Lattice": "VPC Lattice",
}


def _normalise_service(name: str) -> str:
    """Normalise a detected AWS service name to its short canonical form."""
    return _NORMALISE.get(name, name)


def _flatten_questions() -> list[Question]:
    """Return a flat list of all questions across every category."""
    flat: list[Question] = []
    for questions in QUESTION_BANK.values():
        flat.extend(questions)
    return flat


# ═════════════════════════════════════════════════════════════
# QUESTION CONSTRAINTS — inter-question dependency rules
# ═════════════════════════════════════════════════════════════
# Region groups used for constraint-based option filtering.
REGION_GROUPS: dict[str, list[str]] = {
    "EU": [
        "West Europe", "North Europe", "UK South", "France Central",
        "Germany West Central", "Switzerland North", "Sweden Central",
    ],
    "US": [
        "East US", "East US 2", "West US 2", "Central US",
    ],
}

# Each constraint rule:
#   source  – question id whose answer triggers this constraint
#   match   – how to test the source answer
#              type "value"    → exact match (single_choice)
#              type "contains" → answer list includes value (multiple_choice)
#   target  – question id whose options get filtered
#   filter  – how to filter target options
#              type "region_group" → restrict to REGION_GROUPS[group]
#              type "allowed"      → whitelist of allowed option values
#              type "excluded"     → blacklist of excluded option values
#   reason  – human-readable explanation shown to the user
QUESTION_CONSTRAINTS: list[dict[str, Any]] = [
    # ── Data residency → deploy region ────────────────────
    {
        "source": "sec_data_residency",
        "match": {"type": "value", "value": "EU only"},
        "target": "arch_deploy_region",
        "filter": {"type": "region_group", "group": "EU"},
        "reason": "Data residency requirement restricts deployment to EU regions",
    },
    {
        "source": "sec_data_residency",
        "match": {"type": "value", "value": "US only"},
        "target": "arch_deploy_region",
        "filter": {"type": "region_group", "group": "US"},
        "reason": "Data residency requirement restricts deployment to US regions",
    },
    # ── GDPR → deploy region & residency ─────────────────
    {
        "source": "sec_compliance",
        "match": {"type": "contains", "value": "GDPR"},
        "target": "arch_deploy_region",
        "filter": {"type": "region_group", "group": "EU"},
        "reason": "GDPR compliance requires deployment within the EU",
    },
    {
        "source": "sec_compliance",
        "match": {"type": "contains", "value": "GDPR"},
        "target": "sec_data_residency",
        "filter": {"type": "allowed", "values": [
            "EU only", "Specific country", "Multi-region with data sovereignty",
        ]},
        "reason": "GDPR requires data to remain within EU boundaries",
    },
    # ── FedRAMP → deploy region & residency ──────────────
    {
        "source": "sec_compliance",
        "match": {"type": "contains", "value": "FedRAMP"},
        "target": "arch_deploy_region",
        "filter": {"type": "region_group", "group": "US"},
        "reason": "FedRAMP compliance requires US-based deployments",
    },
    {
        "source": "sec_compliance",
        "match": {"type": "contains", "value": "FedRAMP"},
        "target": "sec_data_residency",
        "filter": {"type": "allowed", "values": ["US only"]},
        "reason": "FedRAMP requires data residency within the US",
    },
    # ── HIPAA → deploy region ────────────────────────────
    {
        "source": "sec_compliance",
        "match": {"type": "contains", "value": "HIPAA"},
        "target": "arch_deploy_region",
        "filter": {"type": "region_group", "group": "US"},
        "reason": "HIPAA compliance typically requires US-based deployments",
    },
]


def get_question_constraints() -> dict[str, Any]:
    """Return constraint metadata for the frontend to apply in real-time.

    Returns a dict with:
      - ``constraints``: the list of constraint rules
      - ``region_groups``: mapping of group name → list of Azure region names
    """
    return {
        "constraints": QUESTION_CONSTRAINTS,
        "region_groups": REGION_GROUPS,
    }


# ═════════════════════════════════════════════════════════════
# PUBLIC API
# ═════════════════════════════════════════════════════════════

def generate_questions(detected_services: list[str]) -> list[dict]:
    """Return the relevant subset of guided questions for a set of detected AWS services.

    Questions are included if:
      • their ``condition`` list is empty (always relevant), *or*
      • at least one service in ``condition`` appears in *detected_services*.

    Typically returns 8–15 questions — enough to meaningfully customise the
    translation without overwhelming the user.

    Args:
        detected_services: AWS service names as they appear in the analysis
            (e.g. ``["EC2", "S3", "Lambda", "DynamoDB", "IoT Core"]``).  Both
            short names (``"S3"``) and long names (``"Amazon S3"``) are accepted.

    Returns:
        Ordered list of question dicts, each containing ``id``, ``question``,
        ``type``, ``options``, ``impact``, ``default``, and ``category``.
    """
    normalised: set[str] = {_normalise_service(s) for s in detected_services}

    selected: list[dict] = []
    seen_ids: set[str] = set()

    for category, questions in QUESTION_BANK.items():
        for q in questions:
            if q["id"] in seen_ids:
                continue

            conditions: list[str] = q["condition"]
            if not conditions or any(svc in normalised for svc in conditions):
                entry = {**q, "category": category}
                selected.append(entry)
                seen_ids.add(q["id"])

    # Cap at a reasonable upper bound to maintain UX quality.
    max_questions = 18
    if len(selected) > max_questions:
        # Prioritise: always-on questions first, then service-specific ones.
        always_on = [q for q in selected if not q["condition"]]
        conditional = [q for q in selected if q["condition"]]
        selected = always_on + conditional[: max_questions - len(always_on)]

    return selected


def apply_answers(analysis_result: dict, answers: dict) -> dict:
    """Apply user answers to refine an Azure architecture analysis.

    Creates a **deep copy** of *analysis_result* and mutates the copy — the
    original is never modified.

    Adjustments include:
      • Swapping Azure service mappings (e.g. EMR → Databricks instead of Synapse).
      • Upgrading or downgrading SKU references in mapping notes.
      • Modifying confidence scores when the user confirms preferences.
      • Appending compliance / networking / DR warnings.
      • Adding IaC parameter recommendations under a new ``iac_parameters`` key.

    Args:
        analysis_result: The dict returned by the ``/api/diagrams/{id}/analyze``
            endpoint (or equivalent).  Expected keys: ``mappings``, ``warnings``,
            and optional ``iac_parameters``.
        answers: ``{question_id: user_answer}`` mapping.  Any question not
            present is treated as accepting the default.

    Returns:
        A new analysis dict with adjusted mappings, updated warnings, refined
        confidence scores, and an ``iac_parameters`` section.
    """
    result: dict = copy.deepcopy(analysis_result)

    mappings: list[dict] = result.get("mappings", [])
    warnings: list[str] = result.get("warnings", [])
    iac_params: dict[str, Any] = result.get("iac_parameters", {})

    # Merge defaults for unanswered questions.
    effective: dict[str, Any] = _merge_defaults(answers)

    # ── Apply each rule ──────────────────────────────────────
    _apply_environment(effective, mappings, warnings, iac_params)
    _apply_sku_strategy(effective, mappings, warnings, iac_params)
    _apply_ha_and_dr(effective, mappings, warnings, iac_params)
    _apply_compliance(effective, mappings, warnings, iac_params)
    _apply_network_isolation(effective, mappings, warnings, iac_params)
    _apply_storage_redundancy(effective, mappings, iac_params)
    _apply_spark_runtime(effective, mappings, warnings)
    _apply_functions_plan(effective, mappings, iac_params)
    _apply_cosmosdb(effective, mappings, iac_params)
    _apply_cache_tier(effective, mappings, iac_params)
    _apply_sql_tier(effective, mappings, iac_params)
    _apply_streaming(effective, mappings, iac_params)
    _apply_iot(effective, mappings, warnings, iac_params)
    _apply_monitoring(effective, mappings, warnings, iac_params)
    _apply_containers(effective, mappings, iac_params)
    _apply_ml(effective, mappings, iac_params)
    _apply_iac_style(effective, iac_params)
    _apply_deploy_region(effective, iac_params)
    _apply_encryption(effective, mappings, warnings, iac_params)

    result["mappings"] = mappings
    result["warnings"] = warnings
    result["iac_parameters"] = iac_params

    # ── Recalculate confidence_summary after all rule adjustments ──
    high = len([m for m in mappings if m.get("confidence", 0) >= 0.90])
    medium = len([m for m in mappings if 0.80 <= m.get("confidence", 0) < 0.90])
    low = len([m for m in mappings if m.get("confidence", 0) < 0.80])
    avg = round(
        sum(m.get("confidence", 0) for m in mappings) / max(len(mappings), 1), 2
    )
    result["confidence_summary"] = {
        "high": high,
        "medium": medium,
        "low": low,
        "average": avg,
        "methodology": (
            "Confidence scores are initially set from our curated cross-cloud mapping database "
            "and AI diagram analysis, then adjusted based on your answers to the guided questions. "
            "Factors like target environment, SKU strategy, compliance requirements, HA/DR configuration, "
            "and specific service selections can increase or decrease confidence. "
            "Each mapping includes a detailed breakdown of all factors that influenced its score."
        ),
    }

    return result


# ═════════════════════════════════════════════════════════════
# INTERNAL RULE FUNCTIONS
# ═════════════════════════════════════════════════════════════

def _merge_defaults(answers: Answers) -> Answers:
    """Fill in default values for every question not answered by the user."""
    defaults: dict[str, Any] = {}
    for questions in QUESTION_BANK.values():
        for q in questions:
            defaults[q["id"]] = q["default"]
    merged = {**defaults, **answers}
    return merged


def _swap_azure_service(
    mappings: list[dict],
    source_contains: str,
    old_azure_fragment: str,
    new_azure: str,
    *,
    note_suffix: str = "",
    confidence_delta: float = 0.0,
) -> None:
    """Replace Azure service in any mapping whose source matches *source_contains*
    and whose current azure_service contains *old_azure_fragment*."""
    for m in mappings:
        src = m.get("source_service", "") or ""
        azure = m.get("azure_service", "") or ""
        if source_contains.lower() in src.lower() and old_azure_fragment.lower() in azure.lower():
            m["azure_service"] = new_azure
            if note_suffix:
                m["notes"] = f"{m.get('notes', '')} | {note_suffix}"
            if confidence_delta:
                m["confidence"] = min(1.0, max(0.0, m.get("confidence", 0.8) + confidence_delta))
                _add_confidence_reason(
                    m, f"Service swap to {new_azure}: confidence adjusted by {confidence_delta:+.0%}"
                )


def _add_confidence_reason(mapping: dict, reason: str) -> None:
    """Append a human-readable reason to a mapping's confidence_explanation list."""
    if "confidence_explanation" not in mapping:
        mapping["confidence_explanation"] = []
    mapping["confidence_explanation"].append(reason)


def _boost_confidence(mappings: list[dict], delta: float, reason: str = "") -> None:
    """Raise confidence on all mappings by *delta* (user confirmed preferences)."""
    for m in mappings:
        m["confidence"] = min(1.0, m.get("confidence", 0.8) + delta)
        _add_confidence_reason(
            m, reason or f"User preferences confirmed: confidence boosted by {delta:+.0%}"
        )


# ── Individual rule implementations ───────────────────────

def _apply_environment(
    answers: Answers,
    mappings: list[dict],
    warnings: list[str],
    iac: dict,
) -> None:
    env = answers.get("env_target", "Production")
    iac["environment"] = env.lower().replace("-", "_").replace(" ", "_")

    if env == "Development":
        iac["use_spot_instances"] = True
        iac["auto_shutdown"] = True
        warnings.append(
            "Development environment selected — using lowest-cost defaults, "
            "auto-shutdown enabled, no geo-replication"
        )
        for m in mappings:
            m["confidence"] = min(1.0, m.get("confidence", 0.8) + 0.05)
            _add_confidence_reason(
                m, "Development environment selected — simpler config increases mapping confidence (+5%)"
            )
    elif env == "Multi-environment":
        iac["deploy_environments"] = ["dev", "staging", "prod"]
        warnings.append(
            "Multi-environment requested — IaC will use workspace/variable "
            "sets for dev, staging, and prod"
        )


def _apply_sku_strategy(
    answers: Answers,
    mappings: list[dict],
    warnings: list[str],
    iac: dict,
) -> None:
    strategy = answers.get("arch_sku_strategy", "Balanced")
    iac["sku_strategy"] = strategy

    tier_map = {
        "Cost-optimized (lowest viable tier)": "basic",
        "Balanced (good performance-to-cost ratio)": "standard",
        "Performance-first (premium tiers)": "premium",
        "Enterprise (maximum SLA and features)": "enterprise",
    }
    tier = tier_map.get(strategy, "standard")
    iac["default_tier"] = tier

    if tier == "enterprise":
        warnings.append(
            "Enterprise SKU strategy — all services upgraded to highest tier; "
            "review cost estimate carefully"
        )
        for m in mappings:
            azure = m.get("azure_service", "")
            if "Standard" in azure:
                m["azure_service"] = azure.replace("Standard", "Premium")
            m["confidence"] = min(1.0, m.get("confidence", 0.8) + 0.03)
            _add_confidence_reason(
                m, "Enterprise SKU strategy — premium tier has well-documented migration paths (+3%)"
            )

    elif tier == "basic":
        warnings.append(
            "Cost-optimized tier — some SLA guarantees may be lower; "
            "not recommended for production workloads"
        )
        for m in mappings:
            azure = m.get("azure_service", "")
            if "Premium" in azure:
                m["azure_service"] = azure.replace("Premium", "Standard")


def _apply_ha_and_dr(
    answers: Answers,
    mappings: list[dict],
    warnings: list[str],
    iac: dict,
) -> None:
    ha = answers.get("arch_ha", "Multi-AZ within region (99.95 %)")
    rto = answers.get("arch_dr_rto", "<1 hour")

    iac["high_availability"] = ha
    iac["disaster_recovery_rto"] = rto

    if "active-active" in ha:
        iac["geo_replication"] = True
        iac["traffic_manager_profile"] = "performance"
        iac["paired_region"] = True
        warnings.append(
            "Multi-region active-active — Azure Front Door with geo-replicated "
            "backends will be provisioned; Cosmos DB multi-region writes enabled"
        )
        for m in mappings:
            azure = m.get("azure_service", "")
            if "Cosmos DB" in azure and "multi-region" not in azure.lower():
                m["azure_service"] = f"{azure} (multi-region writes)"
                m["confidence"] = min(1.0, m.get("confidence", 0.8) + 0.05)
                _add_confidence_reason(
                    m, "Active-active HA with multi-region writes — well-supported by Cosmos DB (+5%)"
                )

    elif "active-passive" in ha:
        iac["geo_replication"] = True
        iac["traffic_manager_profile"] = "priority"
        warnings.append(
            "Multi-region active-passive — secondary region with Azure Site "
            "Recovery for failover"
        )

    elif "Single region" in ha:
        iac["availability_zones"] = False
        warnings.append(
            "Single-region deployment without zone redundancy — lower cost "
            "but no AZ-level fault tolerance"
        )
    else:
        iac["availability_zones"] = True

    if "<1 min" in rto:
        iac["hot_standby"] = True
        warnings.append(
            "Hot-standby DR target (<1 min RTO) — requires duplicate "
            "infrastructure in secondary region"
        )


def _apply_compliance(
    answers: Answers,
    mappings: list[dict],
    warnings: list[str],
    iac: dict,
) -> None:
    frameworks = answers.get("sec_compliance", "None")
    if isinstance(frameworks, str):
        frameworks = [frameworks]
    iac["compliance_frameworks"] = frameworks

    residency = answers.get("sec_data_residency", "No restriction")
    iac["data_residency"] = residency

    if "HIPAA" in frameworks:
        iac["hipaa_enabled"] = True
        warnings.append(
            "HIPAA compliance selected — Azure Policy HIPAA/HITRUST initiative "
            "will be assigned; BAA required with Microsoft"
        )

    if "GDPR" in frameworks:
        iac["gdpr_enabled"] = True
        if residency == "No restriction":
            warnings.append(
                "GDPR selected but no data-residency restriction set — "
                "consider restricting to EU regions for full compliance"
            )
        warnings.append(
            "GDPR compliance — data subject request automation and "
            "consent management may need application-level implementation"
        )

    if "PCI-DSS" in frameworks:
        iac["pci_dss_enabled"] = True
        warnings.append(
            "PCI-DSS compliance — CDE (Cardholder Data Environment) segments "
            "require dedicated subnets with NSG/ASG rules"
        )

    if "SOC 2" in frameworks:
        iac["soc2_enabled"] = True

    if "FedRAMP" in frameworks:
        iac["fedramp_enabled"] = True
        iac["azure_government"] = True
        warnings.append(
            "FedRAMP compliance — deployment should target Azure Government "
            "regions (usgovvirginia / usgovarizona)"
        )

    if "ISO 27001" in frameworks:
        iac["iso27001_enabled"] = True

    # Data residency constraints
    region_map = {
        "EU only": ["westeurope", "northeurope", "germanywestcentral", "francecentral"],
        "US only": ["eastus", "eastus2", "westus2", "centralus"],
    }
    if residency in region_map:
        iac["allowed_regions"] = region_map[residency]
        warnings.append(
            f"Data residency: {residency} — Azure Policy will restrict "
            f"deployments to {', '.join(region_map[residency])}"
        )
    elif residency == "Specific country":
        warnings.append(
            "Specific-country data residency — please specify country code "
            "so we can select the appropriate Azure region(s)"
        )


def _apply_network_isolation(
    answers: Answers,
    mappings: list[dict],
    warnings: list[str],
    iac: dict,
) -> None:
    level = answers.get("sec_network_isolation", "VNet integration")
    iac["network_isolation"] = level

    if level == "Full private endpoints":
        iac["private_endpoints"] = True
        iac["public_network_access"] = False
        iac["vnet_integration"] = True
        warnings.append(
            "Full private-endpoint mode — all PaaS services (Storage, SQL, "
            "Cosmos DB, Key Vault, etc.) will use Private Link; some services "
            "may require Premium SKU for PE support"
        )
        # Bump confidence for PE-compatible services
        for m in mappings:
            azure = m.get("azure_service", "")
            if any(svc in azure for svc in [
                "Blob", "SQL", "Cosmos", "Key Vault", "Functions",
                "Container", "Event Hubs", "Service Bus",
            ]):
                m["confidence"] = min(1.0, m.get("confidence", 0.8) + 0.02)
                _add_confidence_reason(
                    m, "Private endpoint compatible service — well-documented Private Link support (+2%)"
                )
    elif level == "VNet integration":
        iac["vnet_integration"] = True
        iac["service_endpoints"] = True
        iac["public_network_access"] = True

    elif level == "Air-gapped / isolated":
        iac["air_gapped"] = True
        iac["private_endpoints"] = True
        iac["public_network_access"] = False
        iac["azure_firewall"] = True
        warnings.append(
            "Air-gapped deployment — Azure Firewall, forced tunnelling, "
            "and no public ingress/egress; requires Azure ExpressRoute "
            "or VPN Gateway for management"
        )

    else:
        iac["public_network_access"] = True


def _apply_storage_redundancy(
    answers: Answers,
    mappings: list[dict],
    iac: dict,
) -> None:
    redundancy = answers.get("data_storage_redundancy", "ZRS")
    iac["storage_redundancy"] = redundancy

    for m in mappings:
        azure = m.get("azure_service", "")
        if any(term in azure for term in ["Blob Storage", "ADLS", "Data Lake", "Azure Files"]):
            m["notes"] = f"{m.get('notes', '')} | Redundancy: {redundancy}"
            if redundancy in ("GRS", "RA-GRS", "GZRS"):
                m["confidence"] = min(1.0, m.get("confidence", 0.8) + 0.03)
                _add_confidence_reason(
                    m, f"Geo-redundant storage ({redundancy}) selected — mature Azure feature (+3%)"
                )


def _apply_spark_runtime(
    answers: Answers,
    mappings: list[dict],
    warnings: list[str],
) -> None:
    runtime = answers.get("data_spark_runtime", "Azure Synapse Spark Pools")
    runtime_map = {
        "Azure Synapse Spark Pools": "Azure Synapse Spark Pool",
        "Azure HDInsight": "Azure HDInsight",
        "Azure Databricks": "Azure Databricks",
    }
    target = runtime_map.get(runtime, "Azure Synapse Spark Pool")

    for m in mappings:
        src = m.get("source_service", "") or ""
        azure = m.get("azure_service", "") or ""
        if "EMR" in src or "Elastic MapReduce" in src:
            if any(frag in azure for frag in ["Synapse", "HDInsight", "Databricks"]):
                m["azure_service"] = target
                m["notes"] = f"{m.get('notes', '')} | User selected: {runtime}"
                m["confidence"] = min(1.0, m.get("confidence", 0.8) + 0.05)
                _add_confidence_reason(
                    m, f"User confirmed Spark runtime: {runtime} — explicit selection increases confidence (+5%)"
                )

    if target == "Azure Databricks":
        warnings.append(
            "Databricks selected as Spark runtime — separate Databricks "
            "workspace will be provisioned; pricing differs from Synapse model"
        )
    elif target == "Azure HDInsight":
        warnings.append(
            "HDInsight selected as Spark runtime — consider HDInsight on AKS "
            "for improved startup times and cluster management"
        )


def _apply_functions_plan(
    answers: Answers,
    mappings: list[dict],
    iac: dict,
) -> None:
    plan = answers.get("data_functions_plan", "Consumption")
    plan_map = {
        "Consumption (pure serverless, pay-per-execution)": "consumption",
        "Premium (pre-warmed instances, VNet support)": "premium",
        "Dedicated App Service Plan": "dedicated",
    }
    plan_key = plan_map.get(plan, "consumption")
    iac["functions_plan"] = plan_key

    for m in mappings:
        azure = m.get("azure_service", "")
        if "Functions" in azure:
            m["notes"] = f"{m.get('notes', '')} | Plan: {plan_key}"
            if plan_key == "premium":
                m["confidence"] = min(1.0, m.get("confidence", 0.8) + 0.03)
                _add_confidence_reason(
                    m, "Premium Functions plan — VNet support and pre-warmed instances improve migration fidelity (+3%)"
                )


def _apply_cosmosdb(
    answers: Answers,
    mappings: list[dict],
    iac: dict,
) -> None:
    throughput = answers.get("data_cosmosdb_throughput", "Provisioned with autoscale")
    api = answers.get("data_cosmosdb_api", "NoSQL (native, recommended)")

    throughput_map = {
        "Serverless (intermittent traffic)": "serverless",
        "Provisioned with manual scaling": "provisioned",
        "Provisioned with autoscale": "autoscale",
    }
    iac["cosmosdb_throughput_mode"] = throughput_map.get(throughput, "autoscale")

    api_map = {
        "NoSQL (native, recommended)": "nosql",
        "MongoDB": "mongodb",
        "Cassandra": "cassandra",
        "Gremlin (graph)": "gremlin",
        "Table": "table",
    }
    iac["cosmosdb_api"] = api_map.get(api, "nosql")

    for m in mappings:
        azure = m.get("azure_service", "")
        if "Cosmos DB" in azure:
            m["notes"] = (
                f"{m.get('notes', '')} | "
                f"API: {iac['cosmosdb_api']}, "
                f"Throughput: {iac['cosmosdb_throughput_mode']}"
            )


def _apply_cache_tier(
    answers: Answers,
    mappings: list[dict],
    iac: dict,
) -> None:
    tier = answers.get("data_cache_tier", "Standard (replicated, 99.9 %)")
    tier_map = {
        "Basic (dev/test, no SLA)": "basic",
        "Standard (replicated, 99.9 %)": "standard",
        "Premium (clustering, VNet, geo-replication)": "premium",
        "Enterprise (Redis Enterprise modules)": "enterprise",
    }
    iac["redis_tier"] = tier_map.get(tier, "standard")

    for m in mappings:
        azure = m.get("azure_service", "")
        if "Redis" in azure or "Cache" in azure:
            m["notes"] = f"{m.get('notes', '')} | Tier: {iac['redis_tier']}"


def _apply_sql_tier(
    answers: Answers,
    mappings: list[dict],
    iac: dict,
) -> None:
    tier = answers.get("data_sql_tier", "General Purpose")
    tier_map = {
        "Basic / Burstable (B-series)": "burstable",
        "General Purpose": "general_purpose",
        "Business Critical / Memory-Optimized": "business_critical",
        "Hyperscale": "hyperscale",
    }
    iac["sql_compute_tier"] = tier_map.get(tier, "general_purpose")

    for m in mappings:
        azure = m.get("azure_service", "")
        if any(db in azure for db in ["SQL Database", "PostgreSQL", "MySQL"]):
            m["notes"] = f"{m.get('notes', '')} | Compute tier: {iac['sql_compute_tier']}"


def _apply_streaming(
    answers: Answers,
    mappings: list[dict],
    iac: dict,
) -> None:
    engine = answers.get("data_streaming_engine", "Azure Event Hubs + Stream Analytics")
    iac["streaming_engine"] = engine

    for m in mappings:
        src = m.get("source_service", "") or ""
        m.get("azure_service", "") or ""
        if any(k in src for k in ["Kinesis", "MSK"]):
            if "Kafka" in engine:
                m["azure_service"] = "Azure Event Hubs (Kafka protocol)"
                m["notes"] = f"{m.get('notes', '')} | Kafka surface enabled"
            elif "Spark" in engine:
                m["azure_service"] = "Azure Event Hubs + Spark Structured Streaming"
                m["notes"] = f"{m.get('notes', '')} | Spark Structured Streaming"


def _apply_iot(
    answers: Answers,
    mappings: list[dict],
    warnings: list[str],
    iac: dict,
) -> None:
    volume = answers.get("iot_message_volume")
    edge = answers.get("iot_edge_computing")
    device_scale = answers.get("iot_device_scale")
    digital_twins = answers.get("iot_digital_twins")

    if volume:
        volume_tier = {
            "<1 M messages/day": "S1",
            "1 M–100 M messages/day": "S2",
            ">100 M messages/day": "S3",
        }
        iac["iot_hub_tier"] = volume_tier.get(volume, "S2")
        if volume == ">100 M messages/day":
            iac["iot_hub_units"] = 10
            warnings.append(
                "High IoT volume (>100 M/day) — IoT Hub S3 with 10 units; "
                "consider IoT Hub device partitions and downstream Event Hubs scaling"
            )

    if edge and "IoT Edge" in edge:
        iac["iot_edge_enabled"] = True

    if device_scale:
        scale_map = {
            "<100 devices": 1,
            "100–10 K devices": 2,
            "10 K–1 M devices": 5,
            ">1 M devices": 10,
        }
        iac["iot_hub_units"] = max(iac.get("iot_hub_units", 1), scale_map.get(device_scale, 1))
        iac["iot_dps_enabled"] = device_scale != "<100 devices"
        if device_scale == ">1 M devices":
            warnings.append(
                ">1 M devices — recommend multiple IoT Hub instances behind "
                "DPS (Device Provisioning Service) for load distribution"
            )

    if digital_twins and "Digital Twins" in digital_twins:
        iac["digital_twins_enabled"] = True
        for m in mappings:
            src = m.get("source_service", "") or ""
            if "TwinMaker" in src:
                m["azure_service"] = "Azure Digital Twins"
                m["confidence"] = min(1.0, m.get("confidence", 0.8) + 0.05)
                _add_confidence_reason(
                    m, "User confirmed Digital Twins usage — direct mapping to Azure Digital Twins (+5%)"
                )
                m["notes"] = f"{m.get('notes', '')} | User confirmed digital twins"


def _apply_monitoring(
    answers: Answers,
    mappings: list[dict],
    warnings: list[str],
    iac: dict,
) -> None:
    depth = answers.get("ops_monitoring_depth", "Application Insights")
    cicd = answers.get("ops_cicd", "GitHub Actions")
    alerting = answers.get("ops_alerting")

    iac["monitoring_depth"] = depth
    iac["cicd_platform"] = cicd

    is_no_monitoring = "None" in depth or "no monitoring" in depth.lower()

    if is_no_monitoring:
        pass  # No monitoring resources added
    elif "Full observability" in depth:
        iac["managed_grafana"] = True
        iac["log_analytics_workspace"] = True
        iac["application_insights"] = True
        warnings.append(
            "Full observability stack — Azure Managed Grafana + Log Analytics "
            "+ Application Insights will be provisioned"
        )
    elif "Sentinel" in depth:
        iac["sentinel_enabled"] = True
        iac["log_analytics_workspace"] = True
        warnings.append(
            "Microsoft Sentinel SIEM enabled — all diagnostic logs will be "
            "forwarded to a centralised Log Analytics workspace"
        )
    elif "Application Insights" in depth:
        iac["application_insights"] = True
        iac["log_analytics_workspace"] = True
    else:
        iac["log_analytics_workspace"] = True

    if cicd == "Azure DevOps Pipelines":
        iac["azure_devops_project"] = True
    elif cicd == "GitHub Actions":
        iac["github_actions"] = True

    if alerting and not is_no_monitoring:
        if "None" not in alerting and "no alerts" not in alerting.lower():
            iac["alerting_channel"] = alerting


def _apply_containers(
    answers: Answers,
    mappings: list[dict],
    iac: dict,
) -> None:
    k8s_tier = answers.get("k8s_cluster_tier")
    node_vm = answers.get("k8s_node_pool")
    container_runtime = answers.get("container_runtime_pref")

    if k8s_tier:
        tier_map = {
            "Free tier (dev/test)": "free",
            "Standard (production SLA, 99.95 %)": "standard",
            "Premium (mission-critical, 99.99 %)": "premium",
        }
        iac["aks_tier"] = tier_map.get(k8s_tier, "standard")

    if node_vm:
        vm_map = {
            "Standard_B2s (burstable, cost-optimized)": "Standard_B2s",
            "Standard_D4s_v5 (general purpose)": "Standard_D4s_v5",
            "Standard_E8s_v5 (memory-optimized)": "Standard_E8s_v5",
            "Standard_F8s_v2 (compute-optimized)": "Standard_F8s_v2",
            "Standard_NC6s_v3 (GPU)": "Standard_NC6s_v3",
        }
        iac["aks_default_vm_size"] = vm_map.get(node_vm, "Standard_D4s_v5")

    if container_runtime:
        runtime_map = {
            "AKS (full Kubernetes)": "AKS",
            "Azure Container Apps (serverless Kubernetes)": "Container Apps",
            "Azure Container Instances (simple single-container)": "Container Instances",
            "Azure App Service (containers on PaaS)": "App Service",
        }
        target = runtime_map.get(container_runtime, "Container Apps")
        iac["container_platform"] = target

        # Remap ECS / Fargate / App Runner targets
        for m in mappings:
            src = m.get("source_service", "") or ""
            if any(svc in src for svc in ["ECS", "Fargate", "App Runner"]):
                azure = m.get("azure_service", "")
                if any(frag in azure for frag in [
                    "Container Instances", "Container Apps", "App Service",
                ]):
                    m["azure_service"] = f"Azure {target}"
                    m["notes"] = f"{m.get('notes', '')} | User selected: {target}"


def _apply_ml(
    answers: Answers,
    mappings: list[dict],
    iac: dict,
) -> None:
    workspace = answers.get("ml_workspace_tier")
    compute = answers.get("ml_compute_target")

    if workspace:
        tier_map = {
            "Basic (notebook-only experimentation)": "basic",
            "Enterprise (managed endpoints, pipelines, AutoML)": "enterprise",
        }
        iac["aml_workspace_tier"] = tier_map.get(workspace, "enterprise")

    if compute:
        compute_map = {
            "CPU clusters (general training)": "cpu",
            "GPU clusters (deep learning)": "gpu",
            "Spark pools (big-data ML)": "spark",
            "Serverless compute (AML managed)": "serverless",
        }
        iac["aml_compute_type"] = compute_map.get(compute, "gpu")

        for m in mappings:
            src = m.get("source_service", "") or ""
            if "SageMaker" in src:
                m["notes"] = f"{m.get('notes', '')} | Compute: {iac['aml_compute_type']}"


def _apply_iac_style(answers: Answers, iac: dict) -> None:
    style = answers.get("arch_iac_style", "Terraform (HCL)")
    style_map = {
        "Terraform (HCL)": "terraform",
        "Bicep": "bicep",
        "ARM Templates (JSON)": "arm",
        "Pulumi": "pulumi",
    }
    iac["iac_format"] = style_map.get(style, "terraform")


def _apply_deploy_region(answers: Answers, iac: dict) -> None:
    """Store the user's chosen deployment region for cost calculations."""
    from services.azure_pricing import display_to_arm
    region_display = answers.get("arch_deploy_region", "West Europe")
    iac["deploy_region"] = display_to_arm(region_display)
    iac["deploy_region_display"] = region_display


def _apply_encryption(
    answers: Answers,
    mappings: list[dict],
    warnings: list[str],
    iac: dict,
) -> None:
    pref = answers.get("sec_encryption", "Platform-managed keys (default)")

    if "Customer-managed" in pref:
        iac["cmk_enabled"] = True
        iac["key_vault_required"] = True
        if "HSM" in pref:
            iac["hsm_backed_keys"] = True
            warnings.append(
                "HSM-backed customer-managed keys — Azure Key Vault Managed HSM "
                "or Dedicated HSM will be provisioned"
            )
        else:
            warnings.append(
                "Customer-managed keys — Azure Key Vault will be provisioned; "
                "all storage, databases, and disks configured with CMK"
            )
        for m in mappings:
            azure = m.get("azure_service", "")
            if any(svc in azure for svc in [
                "Blob", "ADLS", "Data Lake", "SQL", "Cosmos",
                "Redis", "Managed Disk", "Functions",
            ]):
                m["notes"] = f"{m.get('notes', '')} | Encryption: CMK via Key Vault"
    else:
        iac["cmk_enabled"] = False
